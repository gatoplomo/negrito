interrupt_configure.py
======================

.. literalinclude:: ../../../../examples_linux/interrupt_configure.py
    :language: python
    :caption: examples_linux/interrupt_configure.py
    :linenos:
    :lineno-match:
